import React from 'react';

const ReviewBoard = () => {

  return (
	<h1>ReviewBoard</h1>
  );
};

export default ReviewBoard;