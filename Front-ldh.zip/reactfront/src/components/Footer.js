import React from 'react';
import './footer.css';

function Footer() {
  return (
    <div className="Footer">
      <div className="copywriter">©2024 Multicam 29DongSung</div>
    </div>
  );
}

export default Footer;